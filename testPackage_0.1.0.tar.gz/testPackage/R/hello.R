#   Test Package:              'Ctrl + Shift + T'

hello <- function() {
  print("Hello, world!")
}
